// ============================================================
// Configuración de NÚCLEO
// ============================================================
// Para conectar con Google Drive necesitas un OAuth Client ID
// propio (gratuito). Sigue la guía en SETUP.md y pega aquí tu ID.
// Mientras esté vacío, la app funciona igualmente en modo local
// (los datos se guardan en este navegador).

export const GOOGLE_CLIENT_ID = ''
// Ejemplo: '123456789012-abc123def456.apps.googleusercontent.com'

// Ámbito mínimo: la app solo ve los ficheros que ella crea
// y los que tú elijas con el selector de Google.
export const DRIVE_SCOPE = 'https://www.googleapis.com/auth/drive.file'

export const DATA_FILE_NAME = 'nucleo-data.json'
export const DRIVE_FOLDER_NAME = 'NÚCLEO'

export const APP_VERSION = 1
