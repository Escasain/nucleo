import React, { useState } from 'react'
import { StoreProvider, useStore } from './lib/store.jsx'
import { useRoute } from './lib/router.jsx'
import Sidebar from './components/Sidebar.jsx'
import { IconMenu } from './components/Icons.jsx'
import Dashboard from './views/Dashboard.jsx'
import Plan from './views/Plan.jsx'
import SubjectDetail from './views/SubjectDetail.jsx'
import Agenda from './views/Agenda.jsx'
import Study from './views/Study.jsx'
import Settings from './views/Settings.jsx'

function Shell() {
  const { route, navigate } = useRoute()
  const { toasts } = useStore()
  const [menuOpen, setMenuOpen] = useState(false)

  let view
  if (route.name === 'plan') view = <Plan navigate={navigate} />
  else if (route.name === 'subject') view = <SubjectDetail id={route.id} navigate={navigate} />
  else if (route.name === 'agenda') view = <Agenda navigate={navigate} />
  else if (route.name === 'estudio') view = <Study subjectId={route.subjectId} navigate={navigate} />
  else if (route.name === 'ajustes') view = <Settings />
  else view = <Dashboard navigate={navigate} />

  return (
    <>
      <div className="mobile-topbar">
        <button aria-label="Abrir menú" onClick={() => setMenuOpen(true)}>
          <IconMenu />
        </button>
        <span className="brand">NÚCLEO</span>
      </div>
      {menuOpen && <div className="backdrop-mobile" onClick={() => setMenuOpen(false)} />}
      <div className="app">
        <Sidebar activeName={route.name} open={menuOpen} onClose={() => setMenuOpen(false)} />
        <main className="main">{view}</main>
      </div>
      <div className="toast-wrap">
        {toasts.map((t) => (
          <div key={t.id} className="toast">
            {t.msg}
          </div>
        ))}
      </div>
    </>
  )
}

export default function App() {
  return (
    <StoreProvider>
      <Shell />
    </StoreProvider>
  )
}
