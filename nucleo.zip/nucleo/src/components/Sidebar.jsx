import React from 'react'
import { useStore } from '../lib/store.jsx'
import { IconHome, IconBook, IconCalendar, IconCards, IconGear } from './Icons.jsx'

const LINKS = [
  { hash: '#/', name: 'dashboard', label: 'Inicio', Icon: IconHome },
  { hash: '#/plan', name: 'plan', label: 'Plan de estudios', Icon: IconBook },
  { hash: '#/agenda', name: 'agenda', label: 'Agenda', Icon: IconCalendar },
  { hash: '#/estudio', name: 'estudio', label: 'Estudio', Icon: IconCards },
  { hash: '#/ajustes', name: 'ajustes', label: 'Ajustes', Icon: IconGear }
]

const SYNC_LABEL = {
  unconfigured: ['', 'Modo local'],
  local: ['warn', 'Sin conectar a Drive'],
  connecting: ['warn', 'Conectando…'],
  syncing: ['warn', 'Guardando en Drive…'],
  synced: ['ok', 'Sincronizado con Drive'],
  error: ['err', 'Error de sincronización']
}

export default function Sidebar({ activeName, open, onClose }) {
  const { syncStatus } = useStore()
  const [dotClass, label] = SYNC_LABEL[syncStatus] || ['', '']

  return (
    <aside className={`sidebar${open ? ' open' : ''}`}>
      <div className="brand">
        NÚCLEO
        <small>Estudio de tarde</small>
      </div>
      <nav className="nav">
        {LINKS.map(({ hash, name, label: l, Icon }) => (
          <a
            key={name}
            href={hash}
            className={activeName === name || (name === 'plan' && activeName === 'subject') ? 'active' : ''}
            onClick={onClose}
          >
            <Icon />
            {l}
          </a>
        ))}
      </nav>
      <div className="sync-state">
        <span className={`sync-dot ${dotClass}`} />
        {label}
      </div>
    </aside>
  )
}
