import React, { useMemo, useState } from 'react'
import { useStore } from '../lib/store.jsx'
import { subjectById, BLOCKS, STATUS_META } from '../data/curriculum.js'
import { todayISO, formatShort, minutesLabel, relativeLabel, isOverdue } from '../lib/dates.js'
import { pickDriveFiles, isConfigured } from '../lib/driveSync.js'
import Modal from '../components/Modal.jsx'
import Checkbox from '../components/Checkbox.jsx'
import { IconArrowLeft, IconPlus, IconTrash, IconDrive, IconLink, IconCards, IconExternal } from '../components/Icons.jsx'

const TABS = [
  { id: 'clases', label: 'Clases y sesiones' },
  { id: 'recursos', label: 'Recursos' },
  { id: 'evaluaciones', label: 'Evaluaciones' },
  { id: 'notas', label: 'Notas' }
]

function resourceKindLabel(r) {
  if (r.driveId) return 'Google Drive'
  try {
    return new URL(r.url).hostname.replace('www.', '')
  } catch {
    return 'enlace'
  }
}

export default function SubjectDetail({ id, navigate }) {
  const { data, dispatch, toast } = useStore()
  const subject = subjectById(id)
  const [tab, setTab] = useState('clases')
  const [sessionModal, setSessionModal] = useState(false)
  const [taskModal, setTaskModal] = useState(false)
  const [linkModal, setLinkModal] = useState(false)

  const state = data.subjects[id] || {}
  const sessions = useMemo(
    () => data.sessions.filter((s) => s.subjectId === id).sort((a, b) => b.date.localeCompare(a.date)),
    [data.sessions, id]
  )
  const tasks = useMemo(
    () =>
      data.tasks
        .filter((t) => t.subjectId === id)
        .sort((a, b) => (a.due || '9999').localeCompare(b.due || '9999')),
    [data.tasks, id]
  )
  const resources = data.resources[id] || []
  const deckSize = (data.decks[id] || []).length

  if (!subject) {
    return (
      <div className="empty">
        <div className="big">Asignatura no encontrada</div>
        <button className="btn btn-ghost btn-sm" onClick={() => navigate('/plan')}>
          Volver al plan
        </button>
      </div>
    )
  }

  const status = state.status || 'pendiente'

  async function addFromDrive() {
    if (!isConfigured()) {
      toast('Configura Google Drive en Ajustes para vincular ficheros')
      return
    }
    try {
      const files = await pickDriveFiles()
      files.forEach((f) => {
        dispatch({
          type: 'addResource',
          subjectId: id,
          resource: { title: f.name, url: f.url, driveId: f.id, mimeType: f.mimeType }
        })
      })
      if (files.length > 0) toast(`${files.length} recurso(s) añadidos desde Drive`)
    } catch (e) {
      toast(`No se pudo abrir el selector: ${e.message}`)
    }
  }

  return (
    <div>
      <button className="btn btn-ghost btn-sm" onClick={() => navigate('/plan')} style={{ marginBottom: 14 }}>
        <IconArrowLeft style={{ width: 14, height: 14 }} /> Plan de estudios
      </button>

      <div className="page-head" style={{ marginBottom: 18 }}>
        <h1 style={{ fontSize: 26 }}>{subject.name}</h1>
        <div className="sub" style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center', marginTop: 8 }}>
          <span className="chip block" style={{ background: BLOCKS[subject.block].color }}>
            Año {subject.year} · {BLOCKS[subject.block].label}
          </span>
          {subject.english && <span className="chip english">EN INGLÉS</span>}
          {subject.note && <span className="chip">{subject.note}</span>}
          {subject.semestral && <span className="chip">Semestral</span>}
        </div>
      </div>

      <div className="card" style={{ marginBottom: 18, display: 'flex', gap: 16, flexWrap: 'wrap', alignItems: 'flex-end' }}>
        <div style={{ minWidth: 170 }}>
          <label>Estado</label>
          <select
            value={status}
            onChange={(e) => dispatch({ type: 'setSubject', id, patch: { status: e.target.value } })}
          >
            {Object.entries(STATUS_META).map(([k, m]) => (
              <option key={k} value={k}>
                {m.label}
              </option>
            ))}
          </select>
        </div>
        <div style={{ width: 110 }}>
          <label>Nota final</label>
          <input
            type="text"
            inputMode="decimal"
            placeholder="—"
            value={state.grade ?? ''}
            onChange={(e) => dispatch({ type: 'setSubject', id, patch: { grade: e.target.value } })}
          />
        </div>
        <div style={{ flex: 1 }} />
        <button className="btn btn-secondary" onClick={() => navigate(`/estudio/${id}`)}>
          <IconCards style={{ width: 15, height: 15 }} />
          Flashcards ({deckSize})
        </button>
      </div>

      <div className="tabs">
        {TABS.map((t) => (
          <button key={t.id} className={tab === t.id ? 'active' : ''} onClick={() => setTab(t.id)}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'clases' && (
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <h3 style={{ marginBottom: 0 }}>Registro de clases y sesiones de estudio</h3>
            <button className="btn btn-primary btn-sm" onClick={() => setSessionModal(true)}>
              <IconPlus style={{ width: 13, height: 13 }} /> Añadir
            </button>
          </div>
          <div className="row-list">
            {sessions.map((s) => (
              <div key={s.id} className={`row-item${s.done ? ' done' : ''}`}>
                <Checkbox
                  checked={Boolean(s.done)}
                  onChange={() => dispatch({ type: 'updateSession', id: s.id, patch: { done: !s.done } })}
                />
                <div className="grow">
                  <div className="title">{s.title}</div>
                  <div className="meta">
                    {s.type === 'clase' ? 'Clase' : 'Estudio'} · {formatShort(s.date)}
                    {s.durationMin ? ` · ${minutesLabel(s.durationMin)}` : ''}
                    {s.notes ? ` — ${s.notes}` : ''}
                  </div>
                </div>
                <button className="icon-btn" onClick={() => dispatch({ type: 'deleteSession', id: s.id })}>
                  <IconTrash />
                </button>
              </div>
            ))}
            {sessions.length === 0 && (
              <div className="empty">Registra aquí cada clase vista y cada sesión de estudio.</div>
            )}
          </div>
        </div>
      )}

      {tab === 'recursos' && (
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8, marginBottom: 12 }}>
            <h3 style={{ marginBottom: 0 }}>Apuntes, vídeos y material</h3>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn btn-secondary btn-sm" onClick={addFromDrive}>
                <IconDrive style={{ width: 14, height: 14 }} /> Desde Drive
              </button>
              <button className="btn btn-ghost btn-sm" onClick={() => setLinkModal(true)}>
                <IconLink style={{ width: 14, height: 14 }} /> Enlace
              </button>
            </div>
          </div>
          {resources.map((r) => (
            <a key={r.id} className="resource-item" href={r.url} target="_blank" rel="noreferrer">
              {r.driveId ? (
                <IconDrive style={{ width: 16, height: 16, color: 'var(--moss)' }} />
              ) : (
                <IconExternal style={{ width: 16, height: 16, color: 'var(--clay)' }} />
              )}
              <span className="r-title">{r.title}</span>
              <span className="r-type">{resourceKindLabel(r)}</span>
              <button
                className="icon-btn"
                onClick={(e) => {
                  e.preventDefault()
                  dispatch({ type: 'deleteResource', subjectId: id, id: r.id })
                }}
              >
                <IconTrash />
              </button>
            </a>
          ))}
          {resources.length === 0 && (
            <div className="empty">
              Vincula apuntes de tu Drive o enlaces (vídeos, documentación, campus virtual…).
            </div>
          )}
        </div>
      )}

      {tab === 'evaluaciones' && (
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <h3 style={{ marginBottom: 0 }}>Exámenes, entregas y tareas</h3>
            <button className="btn btn-primary btn-sm" onClick={() => setTaskModal(true)}>
              <IconPlus style={{ width: 13, height: 13 }} /> Añadir
            </button>
          </div>
          <div className="row-list">
            {tasks.map((t) => (
              <div key={t.id} className={`row-item${t.done ? ' done' : ''}${!t.done && isOverdue(t.due) ? ' overdue' : ''}`}>
                <Checkbox
                  checked={Boolean(t.done)}
                  onChange={() => dispatch({ type: 'updateTask', id: t.id, patch: { done: !t.done } })}
                />
                <div className="grow">
                  <div className="title">{t.title}</div>
                  <div className="meta">
                    {t.type} · {t.due ? `${formatShort(t.due)} (${relativeLabel(t.due)})` : 'sin fecha'}
                  </div>
                </div>
                <button className="icon-btn" onClick={() => dispatch({ type: 'deleteTask', id: t.id })}>
                  <IconTrash />
                </button>
              </div>
            ))}
            {tasks.length === 0 && <div className="empty">Sin evaluaciones registradas todavía.</div>}
          </div>
        </div>
      )}

      {tab === 'notas' && (
        <div className="card">
          <h3>Notas de la asignatura</h3>
          <textarea
            rows={12}
            placeholder="Apuntes rápidos, temario, contactos del profesor, criterios de evaluación…"
            value={state.notes || ''}
            onChange={(e) => dispatch({ type: 'setSubject', id, patch: { notes: e.target.value } })}
          />
        </div>
      )}

      {sessionModal && (
        <SessionModal
          onClose={() => setSessionModal(false)}
          onSave={(session) => {
            dispatch({ type: 'addSession', session: { ...session, subjectId: id } })
            setSessionModal(false)
          }}
        />
      )}
      {taskModal && (
        <TaskModal
          onClose={() => setTaskModal(false)}
          onSave={(task) => {
            dispatch({ type: 'addTask', task: { ...task, subjectId: id } })
            setTaskModal(false)
          }}
        />
      )}
      {linkModal && (
        <LinkModal
          onClose={() => setLinkModal(false)}
          onSave={(resource) => {
            dispatch({ type: 'addResource', subjectId: id, resource })
            setLinkModal(false)
          }}
        />
      )}
    </div>
  )
}

function SessionModal({ onClose, onSave }) {
  const [title, setTitle] = useState('')
  const [date, setDate] = useState(todayISO())
  const [type, setType] = useState('clase')
  const [durationMin, setDurationMin] = useState('')
  const [notes, setNotes] = useState('')

  return (
    <Modal title="Nueva clase o sesión" onClose={onClose}>
      <div className="field">
        <label>Título</label>
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Tema 3 — Grafos" autoFocus />
      </div>
      <div className="field" style={{ display: 'flex', gap: 10 }}>
        <div style={{ flex: 1 }}>
          <label>Fecha</label>
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </div>
        <div style={{ width: 130 }}>
          <label>Tipo</label>
          <select value={type} onChange={(e) => setType(e.target.value)}>
            <option value="clase">Clase</option>
            <option value="estudio">Estudio</option>
          </select>
        </div>
        <div style={{ width: 110 }}>
          <label>Minutos</label>
          <input
            type="number"
            min="0"
            value={durationMin}
            onChange={(e) => setDurationMin(e.target.value)}
            placeholder="60"
          />
        </div>
      </div>
      <div className="field">
        <label>Notas (opcional)</label>
        <input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Qué se vio, dudas pendientes…" />
      </div>
      <div className="actions">
        <button className="btn btn-ghost" onClick={onClose}>
          Cancelar
        </button>
        <button
          className="btn btn-primary"
          disabled={!title.trim() || !date}
          onClick={() =>
            onSave({
              title: title.trim(),
              date,
              type,
              durationMin: durationMin ? Number(durationMin) : null,
              notes: notes.trim()
            })
          }
        >
          Guardar
        </button>
      </div>
    </Modal>
  )
}

export function TaskModal({ onClose, onSave, subjectSelector, subjects, initialSubject }) {
  const [title, setTitle] = useState('')
  const [due, setDue] = useState('')
  const [type, setType] = useState('entrega')
  const [subjectId, setSubjectId] = useState(initialSubject || '')

  return (
    <Modal title="Nueva evaluación" onClose={onClose}>
      <div className="field">
        <label>Título</label>
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Entrega práctica 1" autoFocus />
      </div>
      {subjectSelector && (
        <div className="field">
          <label>Asignatura</label>
          <select value={subjectId} onChange={(e) => setSubjectId(e.target.value)}>
            <option value="">— Elegir —</option>
            {subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </div>
      )}
      <div className="field" style={{ display: 'flex', gap: 10 }}>
        <div style={{ flex: 1 }}>
          <label>Fecha límite</label>
          <input type="date" value={due} onChange={(e) => setDue(e.target.value)} />
        </div>
        <div style={{ width: 140 }}>
          <label>Tipo</label>
          <select value={type} onChange={(e) => setType(e.target.value)}>
            <option value="entrega">Entrega</option>
            <option value="examen">Examen</option>
            <option value="tarea">Tarea</option>
          </select>
        </div>
      </div>
      <div className="actions">
        <button className="btn btn-ghost" onClick={onClose}>
          Cancelar
        </button>
        <button
          className="btn btn-primary"
          disabled={!title.trim() || (subjectSelector && !subjectId)}
          onClick={() => onSave({ title: title.trim(), due, type, subjectId: subjectSelector ? subjectId : undefined })}
        >
          Guardar
        </button>
      </div>
    </Modal>
  )
}

function LinkModal({ onClose, onSave }) {
  const [title, setTitle] = useState('')
  const [url, setUrl] = useState('')

  return (
    <Modal title="Añadir enlace" onClose={onClose}>
      <div className="field">
        <label>Título</label>
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Vídeo — Introducción a grafos" autoFocus />
      </div>
      <div className="field">
        <label>URL</label>
        <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://…" />
      </div>
      <div className="actions">
        <button className="btn btn-ghost" onClick={onClose}>
          Cancelar
        </button>
        <button
          className="btn btn-primary"
          disabled={!title.trim() || !/^https?:\/\//.test(url)}
          onClick={() => onSave({ title: title.trim(), url: url.trim() })}
        >
          Guardar
        </button>
      </div>
    </Modal>
  )
}
