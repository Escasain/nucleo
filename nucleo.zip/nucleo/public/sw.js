/* NÚCLEO service worker — caché básica para funcionar offline.
   Estrategia: network-first para navegación y assets propios,
   cache-first para fuentes. Nunca cachea llamadas a APIs de Google. */
const CACHE = 'nucleo-v1'

self.addEventListener('install', (event) => {
  self.skipWaiting()
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  )
})

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url)
  if (event.request.method !== 'GET') return
  // No interceptar APIs de Google (auth, drive, picker)
  if (url.hostname.endsWith('googleapis.com') && !url.hostname.startsWith('fonts')) return
  if (url.hostname === 'accounts.google.com' || url.hostname === 'apis.google.com') return

  // Fuentes: cache-first
  if (url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com') {
    event.respondWith(
      caches.match(event.request).then(
        (hit) =>
          hit ||
          fetch(event.request).then((res) => {
            const copy = res.clone()
            caches.open(CACHE).then((c) => c.put(event.request, copy))
            return res
          })
      )
    )
    return
  }

  // Resto (app propia): network-first con fallback a caché
  event.respondWith(
    fetch(event.request)
      .then((res) => {
        if (res.ok && url.origin === self.location.origin) {
          const copy = res.clone()
          caches.open(CACHE).then((c) => c.put(event.request, copy))
        }
        return res
      })
      .catch(() =>
        caches.match(event.request).then((hit) => hit || caches.match('/nucleo/'))
      )
  )
})
